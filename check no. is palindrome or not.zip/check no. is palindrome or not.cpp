#include<iostream>
using namespace std;
int main()
{
	int n,num,digit,rev=0;
	cout<<"Enter a positive number;";
	cin >>num;
	do{
		digit=num%10;
		rev=(rev*10)+digit;
		num=num/10;
	}
	while(num!=0);
	cout<<"The reverse of no. is:"<<rev<<endl;
	if(n==rev)
	cout<<"The  no .is palindrome";
	else
	cout<<"The no . is not a palindrome";
	return 011;
	}
